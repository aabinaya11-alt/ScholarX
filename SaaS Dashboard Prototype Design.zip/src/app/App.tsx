import { useState } from "react";
import {
  LayoutDashboard, FolderKanban, CheckSquare, Users, Building2,
  BarChart3, FileText, Plug, Settings, Bell, HelpCircle, Search,
  ChevronDown, TrendingUp, TrendingDown, ArrowUpRight, MoreHorizontal,
  Zap, Clock, Star, Filter, Calendar, Plus, ChevronRight,
  Activity, Target, DollarSign, Layers, Circle, CheckCircle2,
  AlertCircle, Sparkles, LogOut, X
} from "lucide-react";
import {
  LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend
} from "recharts";

const revenueData = [
  { month: "Jan", revenue: 42000, projects: 18, tasks: 240 },
  { month: "Feb", revenue: 51000, projects: 22, tasks: 310 },
  { month: "Mar", revenue: 47000, projects: 19, tasks: 280 },
  { month: "Apr", revenue: 63000, projects: 28, tasks: 390 },
  { month: "May", revenue: 58000, projects: 25, tasks: 350 },
  { month: "Jun", revenue: 74000, projects: 32, tasks: 420 },
  { month: "Jul", revenue: 69000, projects: 30, tasks: 400 },
  { month: "Aug", revenue: 82000, projects: 36, tasks: 480 },
  { month: "Sep", revenue: 91000, projects: 40, tasks: 530 },
  { month: "Oct", revenue: 88000, projects: 38, tasks: 510 },
  { month: "Nov", revenue: 104000, projects: 45, tasks: 590 },
  { month: "Dec", revenue: 118000, projects: 52, tasks: 660 },
];

const taskStatusData = [
  { name: "Completed", value: 64, color: "#22c55e" },
  { name: "In Progress", value: 22, color: "#4f46e5" },
  { name: "Review", value: 9, color: "#f59e0b" },
  { name: "Blocked", value: 5, color: "#ef4444" },
];

const projects = [
  {
    id: 1, name: "Horizon Design System", client: "Figma Inc.", progress: 87,
    due: "Dec 28, 2025", status: "On Track", priority: "High",
    avatar: "HD", color: "#4f46e5",
  },
  {
    id: 2, name: "Nova E-Commerce Platform", client: "ShopNow Ltd.", progress: 54,
    due: "Jan 15, 2026", status: "At Risk", priority: "Critical",
    avatar: "NE", color: "#7c3aed",
  },
  {
    id: 3, name: "Atlas Analytics Dashboard", client: "DataCorp", progress: 100,
    due: "Dec 10, 2025", status: "Completed", priority: "Medium",
    avatar: "AA", color: "#22c55e",
  },
  {
    id: 4, name: "Pulse Mobile App", client: "HealthTech Co.", progress: 31,
    due: "Feb 3, 2026", status: "On Track", priority: "High",
    avatar: "PM", color: "#f59e0b",
  },
  {
    id: 5, name: "Orbit CRM Integration", client: "SalesForce Pro", progress: 68,
    due: "Jan 22, 2026", status: "On Track", priority: "Medium",
    avatar: "OC", color: "#06b6d4",
  },
];

const activities = [
  { id: 1, user: "Sarah Chen", action: "completed task", target: "UI Component Library", time: "2m ago", avatar: "SC", color: "#4f46e5", type: "complete" },
  { id: 2, user: "Marcus Reid", action: "pushed to", target: "Horizon Design System", time: "18m ago", avatar: "MR", color: "#7c3aed", type: "push" },
  { id: 3, user: "Priya Nair", action: "left a comment on", target: "Q4 Sprint Planning", time: "45m ago", avatar: "PN", color: "#22c55e", type: "comment" },
  { id: 4, user: "James Ko", action: "flagged", target: "Orbit CRM Integration", time: "1h ago", avatar: "JK", color: "#f59e0b", type: "flag" },
  { id: 5, user: "Layla Osei", action: "created milestone in", target: "Pulse Mobile App", time: "3h ago", avatar: "LO", color: "#ef4444", type: "milestone" },
];

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", active: true },
  { icon: FolderKanban, label: "Projects", badge: "12" },
  { icon: CheckSquare, label: "Tasks", badge: "47" },
  { icon: Users, label: "Team" },
  { icon: Building2, label: "Clients" },
  { icon: BarChart3, label: "Analytics" },
  { icon: FileText, label: "Reports" },
  { icon: Plug, label: "Integrations" },
  { icon: Settings, label: "Settings" },
];

const teamMembers = [
  { name: "Sarah Chen", role: "Lead Designer", avatar: "SC", color: "#4f46e5", online: true, hours: "6h 24m" },
  { name: "Marcus Reid", role: "Frontend Dev", avatar: "MR", color: "#7c3aed", online: true, hours: "5h 12m" },
  { name: "Priya Nair", role: "Product Manager", avatar: "PN", color: "#22c55e", online: false, hours: "4h 50m" },
  { name: "James Ko", role: "Backend Dev", avatar: "JK", color: "#f59e0b", online: true, hours: "7h 03m" },
];

const kpiCards = [
  {
    label: "Total Projects", value: "52", trend: "+8", trendUp: true,
    sub: "vs last week", icon: Layers, color: "#4f46e5", bg: "from-indigo-50 to-violet-50",
    iconBg: "bg-indigo-100", iconColor: "text-indigo-600",
  },
  {
    label: "Completed Tasks", value: "1,284", trend: "+124", trendUp: true,
    sub: "vs last week", icon: CheckCircle2, color: "#22c55e", bg: "from-emerald-50 to-green-50",
    iconBg: "bg-emerald-100", iconColor: "text-emerald-600",
  },
  {
    label: "Team Productivity", value: "94.2%", trend: "+3.1%", trendUp: true,
    sub: "vs last week", icon: Target, color: "#7c3aed", bg: "from-violet-50 to-purple-50",
    iconBg: "bg-violet-100", iconColor: "text-violet-600",
  },
  {
    label: "Monthly Revenue", value: "$118K", trend: "+12.4%", trendUp: true,
    sub: "vs last month", icon: DollarSign, color: "#f59e0b", bg: "from-amber-50 to-yellow-50",
    iconBg: "bg-amber-100", iconColor: "text-amber-600",
  },
];

const chartFilters = ["Revenue", "Projects", "Tasks"];

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    "On Track": "bg-emerald-50 text-emerald-700 border border-emerald-200",
    "At Risk": "bg-amber-50 text-amber-700 border border-amber-200",
    "Completed": "bg-indigo-50 text-indigo-700 border border-indigo-200",
    "Blocked": "bg-red-50 text-red-700 border border-red-200",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium ${map[status] ?? "bg-gray-100 text-gray-600"}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${
        status === "On Track" ? "bg-emerald-500" :
        status === "At Risk" ? "bg-amber-500" :
        status === "Completed" ? "bg-indigo-500" : "bg-red-500"
      }`} />
      {status}
    </span>
  );
}

function PriorityBadge({ priority }: { priority: string }) {
  const map: Record<string, string> = {
    "Critical": "bg-red-50 text-red-700 border border-red-200",
    "High": "bg-orange-50 text-orange-700 border border-orange-200",
    "Medium": "bg-sky-50 text-sky-700 border border-sky-200",
    "Low": "bg-gray-100 text-gray-600 border border-gray-200",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${map[priority] ?? "bg-gray-100 text-gray-600"}`}>
      {priority}
    </span>
  );
}

function Avatar({ initials, color, size = "md", online }: { initials: string; color: string; size?: "sm" | "md" | "lg"; online?: boolean }) {
  const sizeMap = { sm: "w-7 h-7 text-xs", md: "w-8 h-8 text-xs", lg: "w-10 h-10 text-sm" };
  return (
    <div className="relative inline-flex">
      <div
        className={`${sizeMap[size]} rounded-full flex items-center justify-center font-semibold text-white flex-shrink-0`}
        style={{ background: color }}
      >
        {initials}
      </div>
      {online !== undefined && (
        <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white ${online ? "bg-emerald-500" : "bg-gray-300"}`} />
      )}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white rounded-xl shadow-xl border border-gray-100 p-3 min-w-[140px]">
        <p className="text-xs text-gray-500 mb-1.5 font-medium">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} className="text-sm font-semibold" style={{ color: p.color }}>
            {p.name === "revenue" ? `$${(p.value / 1000).toFixed(0)}K` : p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function App() {
  const [activeFilter, setActiveFilter] = useState("Revenue");
  const [showNotifications, setShowNotifications] = useState(false);
  const [activeNav, setActiveNav] = useState("Dashboard");

  const chartKey = activeFilter.toLowerCase() as "revenue" | "projects" | "tasks";

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#f5f6fa]" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ─── SIDEBAR ─────────────────────────────────────── */}
      <aside className="w-[260px] flex-shrink-0 bg-white border-r border-gray-100 flex flex-col h-full shadow-sm">
        {/* Logo */}
        <div className="px-6 py-5 border-b border-gray-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-md shadow-indigo-200">
              <Sparkles size={15} className="text-white" />
            </div>
            <div>
              <span className="font-bold text-gray-900 text-[15px] tracking-tight">Synapse</span>
              <span className="text-[10px] text-indigo-500 font-semibold tracking-widest block -mt-0.5">WORKSPACE</span>
            </div>
          </div>
        </div>

        {/* Workspace switcher */}
        <div className="px-4 py-3 border-b border-gray-100">
          <button className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg bg-gray-50 hover:bg-indigo-50 transition-colors group">
            <div className="w-5 h-5 rounded bg-indigo-500 flex items-center justify-center">
              <span className="text-[9px] font-bold text-white">VL</span>
            </div>
            <span className="text-xs font-semibold text-gray-700 group-hover:text-indigo-600 flex-1 text-left">Vertex Labs</span>
            <ChevronDown size={12} className="text-gray-400 group-hover:text-indigo-500" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 overflow-y-auto space-y-0.5">
          <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest px-3 mb-2">Main Menu</p>
          {navItems.slice(0, 5).map(({ icon: Icon, label, badge }) => {
            const isActive = activeNav === label;
            return (
              <button
                key={label}
                onClick={() => setActiveNav(label)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 group ${
                  isActive
                    ? "bg-indigo-50 text-indigo-700"
                    : "text-gray-500 hover:bg-gray-50 hover:text-gray-800"
                }`}
              >
                <Icon size={16} className={isActive ? "text-indigo-600" : "text-gray-400 group-hover:text-gray-600"} />
                <span className="flex-1 text-left">{label}</span>
                {badge && (
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${isActive ? "bg-indigo-600 text-white" : "bg-gray-200 text-gray-500"}`}>
                    {badge}
                  </span>
                )}
                {isActive && <div className="w-1 h-4 rounded-full bg-indigo-500 absolute right-3" />}
              </button>
            );
          })}

          <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest px-3 mb-2 mt-5">Reports & Tools</p>
          {navItems.slice(5).map(({ icon: Icon, label }) => {
            const isActive = activeNav === label;
            return (
              <button
                key={label}
                onClick={() => setActiveNav(label)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 group ${
                  isActive
                    ? "bg-indigo-50 text-indigo-700"
                    : "text-gray-500 hover:bg-gray-50 hover:text-gray-800"
                }`}
              >
                <Icon size={16} className={isActive ? "text-indigo-600" : "text-gray-400 group-hover:text-gray-600"} />
                <span className="flex-1 text-left">{label}</span>
              </button>
            );
          })}
        </nav>

        {/* Upgrade card */}
        <div className="p-4 border-t border-gray-100">
          <div className="rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 p-4 shadow-lg shadow-indigo-200 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -mr-6 -mt-6" />
            <div className="absolute bottom-0 left-0 w-12 h-12 bg-white/10 rounded-full -ml-4 -mb-4" />
            <Zap size={18} className="text-yellow-300 mb-2" />
            <p className="text-white text-xs font-bold mb-0.5">Upgrade to Pro</p>
            <p className="text-white/70 text-[11px] mb-3 leading-relaxed">Unlock unlimited projects & advanced analytics</p>
            <button className="w-full bg-white text-indigo-700 text-xs font-bold py-2 rounded-lg hover:bg-indigo-50 transition-colors">
              Get Pro — $29/mo
            </button>
          </div>

          {/* User */}
          <div className="flex items-center gap-2.5 mt-4 px-1">
            <Avatar initials="AL" color="#4f46e5" size="md" online={true} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-gray-800 truncate">Alex Lin</p>
              <p className="text-xs text-gray-400 truncate">Project Director</p>
            </div>
            <button className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-lg hover:bg-gray-100">
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </aside>

      {/* ─── MAIN AREA ───────────────────────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden">

        {/* ─── TOP NAV ─────────────────────────────────── */}
        <header className="bg-white border-b border-gray-100 px-6 py-3.5 flex items-center gap-4 flex-shrink-0 shadow-sm">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search projects, tasks, clients..."
              className="w-full pl-10 pr-4 py-2 text-sm bg-gray-50 border border-gray-200 rounded-xl text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300 transition-all"
            />
            <kbd className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-gray-400 bg-white border border-gray-200 rounded px-1.5 py-0.5 font-mono">⌘K</kbd>
          </div>

          <div className="flex items-center gap-2 ml-auto">
            {/* Date filter */}
            <button className="flex items-center gap-2 px-3 py-2 text-sm text-gray-600 bg-gray-50 border border-gray-200 rounded-xl hover:bg-gray-100 transition-colors">
              <Calendar size={14} className="text-indigo-500" />
              <span className="font-medium text-xs">Dec 2025</span>
              <ChevronDown size={12} className="text-gray-400" />
            </button>

            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative w-9 h-9 flex items-center justify-center rounded-xl bg-gray-50 border border-gray-200 text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200 transition-all"
              >
                <Bell size={16} />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white" />
              </button>

              {showNotifications && (
                <div className="absolute right-0 top-12 w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-bold text-gray-800">Notifications</p>
                    <button onClick={() => setShowNotifications(false)} className="text-gray-400 hover:text-gray-600 p-1 rounded-lg hover:bg-gray-100">
                      <X size={14} />
                    </button>
                  </div>
                  {activities.slice(0, 4).map((a) => (
                    <div key={a.id} className="flex items-start gap-3 px-4 py-3 hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-0">
                      <Avatar initials={a.avatar} color={a.color} size="sm" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-gray-700 leading-relaxed">
                          <span className="font-semibold">{a.user}</span> {a.action}{" "}
                          <span className="font-semibold text-indigo-600">{a.target}</span>
                        </p>
                        <p className="text-[11px] text-gray-400 mt-0.5">{a.time}</p>
                      </div>
                    </div>
                  ))}
                  <div className="px-4 py-3 text-center">
                    <button className="text-xs text-indigo-600 font-semibold hover:underline">View all notifications</button>
                  </div>
                </div>
              )}
            </div>

            <button className="w-9 h-9 flex items-center justify-center rounded-xl bg-gray-50 border border-gray-200 text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200 transition-all">
              <HelpCircle size={16} />
            </button>

            {/* Profile */}
            <button className="flex items-center gap-2.5 pl-2 pr-3 py-1.5 rounded-xl hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-all">
              <Avatar initials="AL" color="#4f46e5" size="sm" online />
              <div className="text-left">
                <p className="text-xs font-semibold text-gray-800 leading-none">Alex Lin</p>
                <p className="text-[11px] text-gray-400 mt-0.5">Director</p>
              </div>
              <ChevronDown size={12} className="text-gray-400 ml-1" />
            </button>
          </div>
        </header>

        {/* ─── CONTENT ─────────────────────────────────── */}
        <main className="flex-1 overflow-y-auto px-6 py-6 space-y-6" style={{ scrollbarWidth: "none" }}>

          {/* Page header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900 tracking-tight">Good morning, Alex 👋</h1>
              <p className="text-sm text-gray-500 mt-0.5">Here's what's happening across your workspace today.</p>
            </div>
            <button className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow-md shadow-indigo-200 transition-all">
              <Plus size={15} />
              New Project
            </button>
          </div>

          {/* ── SECTION A: KPI CARDS ─────────────────── */}
          <div className="grid grid-cols-4 gap-4">
            {kpiCards.map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.label}
                  className={`bg-white rounded-2xl p-5 border border-gray-100 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer group relative overflow-hidden`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${card.bg} opacity-0 group-hover:opacity-40 transition-opacity`} />
                  <div className="relative">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-10 h-10 rounded-xl ${card.iconBg} flex items-center justify-center`}>
                        <Icon size={18} className={card.iconColor} />
                      </div>
                      <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full ${card.trendUp ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-600"}`}>
                        {card.trendUp ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                        {card.trend}
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900 tracking-tight mb-1">{card.value}</p>
                    <p className="text-sm font-medium text-gray-500">{card.label}</p>
                    <p className="text-xs text-gray-400 mt-1">{card.sub}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* ── SECTION B: ANALYTICS ────────────────── */}
          <div className="grid grid-cols-3 gap-4">
            {/* Line chart */}
            <div className="col-span-2 bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="text-sm font-bold text-gray-800">Growth Overview</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Full year performance — 2025</p>
                </div>
                <div className="flex items-center gap-1 bg-gray-50 rounded-xl p-1 border border-gray-200">
                  {chartFilters.map((f) => (
                    <button
                      key={f}
                      onClick={() => setActiveFilter(f)}
                      className={`text-xs px-3 py-1.5 rounded-lg font-semibold transition-all ${
                        activeFilter === f
                          ? "bg-indigo-600 text-white shadow-sm"
                          : "text-gray-500 hover:text-gray-700"
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              <ResponsiveContainer width="100%" height={210}>
                <AreaChart data={revenueData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#4f46e5" stopOpacity={0.18} />
                      <stop offset="100%" stopColor="#4f46e5" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f5" vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false}
                    tickFormatter={(v) => chartKey === "revenue" ? `$${v / 1000}K` : String(v)} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey={chartKey}
                    stroke="#4f46e5"
                    strokeWidth={2.5}
                    fill="url(#areaGrad)"
                    dot={false}
                    activeDot={{ r: 5, fill: "#4f46e5", stroke: "white", strokeWidth: 2 }}
                  />
                </AreaChart>
              </ResponsiveContainer>

              {/* Stats row */}
              <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-gray-100">
                {[
                  { label: "Peak Month", val: "December", sub: "$118K revenue" },
                  { label: "Avg Monthly", val: "$73.9K", sub: "+28% vs 2024" },
                  { label: "YTD Total", val: "$887K", sub: "On target for $1M" },
                ].map((s) => (
                  <div key={s.label}>
                    <p className="text-xs text-gray-400 font-medium">{s.label}</p>
                    <p className="text-sm font-bold text-gray-800 mt-0.5">{s.val}</p>
                    <p className="text-xs text-emerald-600 font-medium mt-0.5">{s.sub}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Donut + task status */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-gray-800">Task Status</h3>
                  <p className="text-xs text-gray-400 mt-0.5">This month breakdown</p>
                </div>
                <button className="text-gray-400 hover:text-gray-600 p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
                  <MoreHorizontal size={15} />
                </button>
              </div>

              <div className="flex-1 flex flex-col items-center justify-center">
                <div className="relative">
                  <ResponsiveContainer width={160} height={160}>
                    <PieChart>
                      <Pie
                        data={taskStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={52}
                        outerRadius={72}
                        strokeWidth={0}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {taskStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className="text-2xl font-bold text-gray-900">64%</span>
                    <span className="text-[10px] text-gray-400 font-medium">Done</span>
                  </div>
                </div>

                <div className="w-full space-y-2.5 mt-4">
                  {taskStatusData.map((item) => (
                    <div key={item.name} className="flex items-center gap-2.5">
                      <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: item.color }} />
                      <span className="text-xs text-gray-600 flex-1 font-medium">{item.name}</span>
                      <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${item.value}%`, background: item.color }} />
                      </div>
                      <span className="text-xs font-semibold text-gray-700 w-8 text-right">{item.value}%</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* CTA */}
              <button className="mt-4 w-full flex items-center justify-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-800 py-2 rounded-xl border border-indigo-100 hover:bg-indigo-50 transition-all">
                View full report <ArrowUpRight size={12} />
              </button>
            </div>
          </div>

          {/* ── SECTIONS C + D ───────────────────────── */}
          <div className="grid grid-cols-3 gap-4">

            {/* SECTION C: Projects table */}
            <div className="col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
                <div>
                  <h3 className="text-sm font-bold text-gray-800">Active Projects</h3>
                  <p className="text-xs text-gray-400 mt-0.5">12 total · 3 due this week</p>
                </div>
                <div className="flex items-center gap-2">
                  <button className="flex items-center gap-1.5 text-xs font-semibold text-gray-500 hover:text-gray-700 px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                    <Filter size={12} />
                    Filter
                  </button>
                  <button className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 px-3 py-1.5 rounded-lg hover:bg-indigo-50 transition-colors border border-indigo-100">
                    View All
                  </button>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50/60 border-b border-gray-100">
                      {["Project", "Client", "Progress", "Due Date", "Status", "Priority"].map((col) => (
                        <th key={col} className="px-5 py-3 text-left text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {projects.map((p, i) => (
                      <tr
                        key={p.id}
                        className={`border-b border-gray-50 hover:bg-indigo-50/30 transition-colors cursor-pointer group ${i === projects.length - 1 ? "border-0" : ""}`}
                      >
                        <td className="px-5 py-3.5">
                          <div className="flex items-center gap-2.5">
                            <div className="w-7 h-7 rounded-lg flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0" style={{ background: p.color }}>
                              {p.avatar}
                            </div>
                            <span className="text-sm font-semibold text-gray-800 group-hover:text-indigo-700 transition-colors whitespace-nowrap">{p.name}</span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-sm text-gray-500 whitespace-nowrap">{p.client}</td>
                        <td className="px-5 py-3.5">
                          <div className="flex items-center gap-2.5 min-w-[100px]">
                            <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full transition-all"
                                style={{
                                  width: `${p.progress}%`,
                                  background: p.progress === 100 ? "#22c55e" : p.progress < 40 ? "#f59e0b" : "#4f46e5"
                                }}
                              />
                            </div>
                            <span className="text-xs font-semibold text-gray-600 w-8 text-right">{p.progress}%</span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-sm text-gray-500 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <Calendar size={12} className="text-gray-400" />
                            {p.due}
                          </div>
                        </td>
                        <td className="px-5 py-3.5"><StatusBadge status={p.status} /></td>
                        <td className="px-5 py-3.5"><PriorityBadge priority={p.priority} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* SECTION D: Activity + team */}
            <div className="flex flex-col gap-4">

              {/* Activity feed */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm flex-1 overflow-hidden flex flex-col">
                <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
                  <div className="flex items-center gap-2">
                    <Activity size={14} className="text-indigo-500" />
                    <h3 className="text-sm font-bold text-gray-800">Recent Activity</h3>
                  </div>
                  <button className="text-xs text-indigo-600 font-semibold hover:underline">All</button>
                </div>
                <div className="flex-1 overflow-y-auto py-2" style={{ scrollbarWidth: "none" }}>
                  {activities.map((a, i) => (
                    <div key={a.id} className="flex items-start gap-3 px-5 py-3 hover:bg-gray-50/70 transition-colors">
                      <Avatar initials={a.avatar} color={a.color} size="sm" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-gray-700 leading-relaxed">
                          <span className="font-semibold text-gray-900">{a.user}</span>{" "}
                          <span className="text-gray-500">{a.action}</span>{" "}
                          <span className="font-semibold text-indigo-600">{a.target}</span>
                        </p>
                        <p className="text-[11px] text-gray-400 mt-0.5 flex items-center gap-1">
                          <Clock size={10} />
                          {a.time}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Time tracking / Team */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
                  <div className="flex items-center gap-2">
                    <Clock size={14} className="text-violet-500" />
                    <h3 className="text-sm font-bold text-gray-800">Team Today</h3>
                  </div>
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">3 Active</span>
                </div>
                <div className="p-3 space-y-1">
                  {teamMembers.map((m) => (
                    <div key={m.name} className="flex items-center gap-2.5 px-2 py-2 rounded-xl hover:bg-gray-50 transition-colors">
                      <Avatar initials={m.avatar} color={m.color} size="sm" online={m.online} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-gray-800 truncate">{m.name}</p>
                        <p className="text-[11px] text-gray-400 truncate">{m.role}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-semibold text-gray-700" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{m.hours}</p>
                        <p className="text-[10px] text-gray-400">tracked</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* Bottom spacer */}
          <div className="h-2" />
        </main>
      </div>
    </div>
  );
}
